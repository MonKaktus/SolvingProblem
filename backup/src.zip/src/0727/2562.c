#include <stdio.h>

int main(int argc, char* argv[]) {
	printf("Hello, goorm!\n");
	
	return 0;
}